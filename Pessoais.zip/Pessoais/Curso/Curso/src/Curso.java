import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Curso {
    private String code;
    private String nome;
    ArrayList<Aluno> listaDeAlunos = new ArrayList<Aluno>();

    public Curso(String code, String nome){
        this.code = code;
        this.nome = nome;
        this.listaDeAlunos = new ArrayList<>();
    }

    public String getCode(){
        return this.code;
    }
    public String getNome(){
        return this.nome;
    }
    public ArrayList<Aluno> getListaDeAlunos(){
        return this.listaDeAlunos;
    }

    public void matricularAluno(Aluno aluno){
        listaDeAlunos.add(aluno);
        System.out.println("Aluno: " + aluno.getNome() + " matriculado com sucesso!");
    }
    public void listarAlunos() {
        System.out.println("Alunos Matriculados no Curso: " + this.nome);
        for (Aluno aluno : this.listaDeAlunos){
            System.out.println("Matricula: " + aluno.getMatricula() + ", Nome: " + aluno.getNome());
        }
        System.out.println("---------------------------------------");
    }
    public void cancelarMatricula(String matriculaDoAluno){
        Aluno alunoParaRemover = null;

        for (Aluno aluno : this.listaDeAlunos) {
            if (aluno.getMatricula().equals(matriculaDoAluno)) {
                alunoParaRemover = aluno;
                break;
            } else {
                System.out.println("Aluno com matricula " + matriculaDoAluno + " não foi encontrado no curso!");
            }
        }

        if (alunoParaRemover != null) {
            this.listaDeAlunos.remove(alunoParaRemover);
            System.out.println("Matricula de " + alunoParaRemover + " cancelada com sucesso");
        }
    }

}
