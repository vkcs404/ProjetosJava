public class TesteHeitoria {
    public static void main(String[] args) {
        Curso poo = new Curso("001", "Programação Orientada Objeto");
        Curso bd = new Curso("002", "Banco de Dados");

        Aluno aluno1 = new Aluno("A001", "Vitor");
        Aluno aluno2 = new Aluno("A002", "Yasmin");
        Aluno aluno3 = new Aluno("A003", "Abmael");

        poo.matricularAluno(aluno1);
        poo.matricularAluno(aluno2);

        bd.matricularAluno(aluno1);
        bd.matricularAluno(aluno3);

        System.out.println("------------------------------------------");

        poo.listarAlunos();
        System.out.println("-------------------------------------------");

        bd.listarAlunos();
        System.out.println("--------------------------------------------");

        poo.cancelarMatricula("A002");

        poo.listarAlunos();
    }


}
