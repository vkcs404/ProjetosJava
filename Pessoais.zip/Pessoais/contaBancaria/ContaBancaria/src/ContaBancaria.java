public class ContaBancaria {
    private String numeroDaConta;
    private String nomeDoTitular;
    private double saldo;

    public ContaBancaria(String numeroDaConta, String nomeDoTitular){
        this.numeroDaConta = numeroDaConta;
        this.nomeDoTitular = nomeDoTitular;
        this.saldo = 0.00;
    }

    public String getNumeroDaConta(){
        return this.numeroDaConta;
    }
    public String getNomeDoTitular(){
        return this.nomeDoTitular;
    }
    public double getSaldo(){
        return this.saldo;
    }

    public void depositar(double valor){
        if (valor > 0){
            this.saldo += valor;
        }
    }

    public boolean sacar(double valor){
        if (valor > 0){
            if (saldo >= valor){
                this.saldo -= valor;
            }
        }
        return false;
    }
}
