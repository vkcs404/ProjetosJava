public class TesteContaBancaria {
    public static void main(String[] args){
        ContaBancaria ContaBancaria1 = new ContaBancaria("0001", "Vitor Santos");

        System.out.println("Numero da Conta: " + ContaBancaria1.getNumeroDaConta());
        System.out.println("Nome do Titular: " + ContaBancaria1.getNomeDoTitular());
        System.out.println("Saldo: " + ContaBancaria1.getSaldo());

        ContaBancaria1.depositar(500.0);
        System.out.println("Saldo: " + ContaBancaria1.getSaldo() );

        if (ContaBancaria1.sacar(200.0)) {
            System.out.println("Saque realizado com sucesso!");
        }
        System.out.println("Saldo: " + ContaBancaria1.getSaldo());

        if (ContaBancaria1.sacar(1000.0)) {
            System.out.println("Saque realizado com sucesso!");
        } else {
            System.out.println("Saldo insuficiente para saque!");
            System.out.println("Saldo: " + ContaBancaria1.getSaldo());
        }
    }

}
