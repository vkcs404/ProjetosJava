public class Motor{
    private int potencia;
    private String tipoCombustivel;
    private boolean ligado;

    public Motor(int potencia, String tipoCombustivel){
        this.potencia = potencia;
        this.tipoCombustivel = tipoCombustivel;
        this.ligado = false;
    }

    public int getPotencia(){
        return this.potencia;
    }
    public String getTipoCombustivel(){
        return this.tipoCombustivel;
    }

    public boolean isLigado() {
        return this.ligado;
    }

    public void ligar(){
        this.ligado = true;
    }
    public void desligar(){
        this.ligado = false;
    }

}


