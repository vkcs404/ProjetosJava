public class TesteCarro {
    public static void main(String[] args){
        Motor motor = new Motor(140, "Diesel");

        Carro carro = new Carro("Toyota", "Hilux", motor);

        System.out.println(carro.imprimirStatus());

        carro.ligarCarro();
        System.out.println(carro.imprimirStatus());

        carro.desligarCarro();
        System.out.println(carro.imprimirStatus());
    }
}
