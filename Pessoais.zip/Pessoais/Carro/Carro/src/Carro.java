public class Carro {
    private String marca;
    private String modelo;
    private Motor motor;


    public Carro(String marca, String modelo, Motor motor){
        this.marca = marca;
        this.modelo = modelo;
        this.motor = motor;
    }

    public String getMarca(){
        return this.marca;
    }
    public String getModelo(){
        return this.modelo;
    }
    public Motor getMotor(){
        return this.motor;
    }

    public void ligarCarro(){
        if (motor != null){
            motor.ligar();
        }

    }
    public void desligarCarro(){
        motor.desligar();
    }

    public String imprimirStatus(){
        return "Marca: " + getMarca() + ", Modelo: " + getModelo() + ", Motor: " + motor.isLigado();
    }
}
