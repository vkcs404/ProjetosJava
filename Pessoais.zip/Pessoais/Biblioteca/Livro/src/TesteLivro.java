public class TesteLivro {
    public static void main(String[] args){
        Livro livro1 = new Livro("Senhor Dos Aneis", "J.R.R Tolkien", 1200, 1954);
        Livro livro2 = new Livro("Harry Potter", "J. k Rowling", 208 , 1965);

        System.out.println(livro1.obterResumo());
        System.out.println(livro2.obterResumo());

        livro2.setTitulo("Harry Potter e a Pedra Filosofal");
        livro2.setAutor("J. K Rowling");
        System.out.println(livro2.obterResumo());
    }
}
