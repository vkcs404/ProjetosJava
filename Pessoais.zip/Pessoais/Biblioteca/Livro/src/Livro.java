public class Livro {
    private String titulo;
    private String autor;
    private int numeroDePaginas;
    private int anoPublicado;

    public Livro(String titulo, String autor, int numeroDePaginas, int anoPublicado){
        this.titulo = titulo;
        this.autor = autor;
        this.numeroDePaginas = numeroDePaginas;
        this.anoPublicado = anoPublicado;
    }

    public String getTitulo(){
        return this.titulo;
    }
    public String getAutor(){
        return this.autor;
    }
    public int getNumeroDePaginas(){
        return this.numeroDePaginas;
    }
    public int getAnoPublicado(){
        return this.anoPublicado;
    }

    public void setTitulo(String novoTitulo){
        this.titulo = novoTitulo;
    }
    public void setAutor(String novoAutor){
        this.autor = novoAutor;
    }

    public String obterResumo(){
        return "O livro " + getTitulo() + ", Escrito por " + getAutor() + ", foi publicado em " + getAnoPublicado() + ",e tem " + getNumeroDePaginas() + " paginas";
    }
}
