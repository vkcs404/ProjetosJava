public class Produto {
    private String codigo;
    private String nome;
    private double preco;
    private int quantidadeEmEstoque;

    public Produto(String codigo, String nome, double preco) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantidadeEmEstoque = 0;
    }

    public String getCodigo() {
        return this.codigo;
    }
    public String getNome(){
        return this.nome;
    }
    public double getPreco(){
        return this.preco;
    }
    public int getQuantidadeEmEstoque(){
        return this.quantidadeEmEstoque;
    }

    public void setPreco(double novoPreco){
        this.preco = novoPreco;
    }

    public void adicionarEstoque(int quantidade){
        this.quantidadeEmEstoque += quantidade;
    }

    public void removerEstoque(int quantidade){
        this.quantidadeEmEstoque -= quantidade;
    }
}
