public class TesteEstoque {
    public static void main(String[] args){
        Produto produto1 = new Produto("001","MacBook",2700.00);

        System.out.println("Codigo: " + produto1.getCodigo());
        System.out.println("Nome: " + produto1.getNome());
        System.out.println("Peco: " + produto1.getPreco());
        System.out.println("Estoque: " + produto1.getQuantidadeEmEstoque());

        produto1.adicionarEstoque(10);
        System.out.println("Estoque: " + produto1.getQuantidadeEmEstoque());

        produto1.removerEstoque(3);
        System.out.println("Estoque: " + produto1.getQuantidadeEmEstoque());

        produto1.setPreco(3000);
        System.out.println("Preço: " + produto1.getPreco());
    }
}
